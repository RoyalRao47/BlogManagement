﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class Property
    {
        public short PropertyId { get; set; }
        public string PropertyName { get; set; }
        public short? PropertyDestId { get; set; }
        public short? PropertyRegionId { get; set; }
        public short? PropertyResortId { get; set; }
        public string Description { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }
        public short? RoomTypeId { get; set; }
        public byte? AccomRatingId { get; set; }
        public byte? PropertyAccomTypeId { get; set; }
        public bool? IsShowDisneyTicketTransfer { get; set; }
        public bool? IsBookingCaption { get; set; }
        public string? PropertyImage { get; set; }
        public string? PropertyImageTwo { get; set; }
        // Navigation properties
        public virtual Destination Destination { get; set; }
        public virtual PropertyRegion PropertyRegion { get; set; }
        public virtual PropertyResort PropertyResort { get; set; }
        public virtual RoomType? RoomType { get; set; }
        public virtual PropertyAccomType PropertyAccomType { get; set; }
    }
}
