﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class EnquiryNote
    {
        public long EnquiryNoteId { get; set; }
        public long EnquiryId { get; set; }
        public string Note { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }

        public virtual Enquiry Enquiry { get; set; }
        public virtual AdminUser CreatedByUser { get; set; }
    }
}
