﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class AirClass
    {
        public short AirClassId { get; set; }
        public short? AirlineId { get; set; }
        public string AirClassName { get; set; }
        public string ShortDescription { get; set; }
        public short DisplayOrder { get; set; }
        public short? AdultBaggage { get; set; }
        public short? ChildBaggage { get; set; }
        public short? InfantBaggage { get; set; }
        public short AdultQuantity { get; set; }
        public short ChildQuantity { get; set; }
        public short InfantQuantity { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }
        public short? CabineTypeId { get; set; }

        // Navigation properties
        public virtual Airline Airline { get; set; }
        public virtual FlightCabin FlightCabin { get; set; }
    }
}
