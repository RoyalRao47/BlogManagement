﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class PropertyRegion
    {
        public short PropertyRegionId { get; set; }
        public string PropertyRegionName { get; set; }
        public short? PropertyDestId { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }

        // Navigation property
        public virtual Destination Destination { get; set; }
    }
}
