﻿

namespace Valerio.Data.Models
{
    public class QuoteFlightAdditionalLeg
    {
       
        public long QuoteFlightAdditionalId { get; set; }

      
        public long QuoteFlightId { get; set; }

        public short? AirClassId { get; set; }

        public DateTime? DepartureDate { get; set; }

        
        public byte Duration { get; set; }

        public short? DepartAirportId { get; set; }

        public short? ArrivalAirportId { get; set; }

        public DateTime? ArrivalDateTime { get; set; }

        public byte? SortLegIndex { get; set; }

        public bool? IsInbound { get; set; }

        
        public string ManualClass { get; set; }

        
        public string FlightNumber { get; set; }

        
        public string SeatNumber { get; set; }
        public Int16? NoOfStops { get; set; }
        public virtual QuoteFlight QuoteFlight { get; set; }

       
        public virtual FlightAirport? DepartAirport { get; set; }

        public virtual FlightAirport? ArrivalAirport { get; set; }

        
        public virtual AirClass AirClass { get; set; }
    }
}
