﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class QuoteFlight
    {
        public long QuoteFlightId { get; set; }
        public long EnquiryQuoteId { get; set; }
        public short? AirlineId { get; set; }
        public short? AirClassId { get; set; }
        public byte IsFlightDirect { get; set; }
        public bool IsIncludeTaxes { get; set; }
        public decimal AdultNett { get; set; }
        public decimal ChildNett { get; set; }
        public decimal InfantNett { get; set; }
        public decimal? TeenNett { get; set; }
        public string Notes { get; set; }
        public string ExternalURL { get; set; }
        public int EmployeeId { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public string InternalNotes { get; set; }
        public byte? Duration { get; set; }
        public string ManualAirline { get; set; }
        public string SalesPoint { get; set; }

        public virtual EnquiryQuote EnquiryQuote { get; set; }
        public virtual Airline? Airline { get; set; }
        public virtual AirClass? AirClass { get; set; }
        public virtual ICollection<QuoteFlightAdditionalLeg> QuoteFlightAdditionalLegs { get; set; }
    }
}
