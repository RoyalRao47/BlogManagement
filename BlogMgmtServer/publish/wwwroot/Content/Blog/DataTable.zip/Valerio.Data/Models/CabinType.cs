﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class CabinType
    {
        public byte CabinTypeId { get; set; }

        public string CabinTypeName { get; set; } = null!;

        public DateTime AddDate { get; set; }

        public DateTime ModifyDate { get; set; }

        public string Ipaddress { get; set; } = null!;

        public bool IsActive { get; set; }
    }
}
