﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class EnquiryQuote
    {
        public long EnquiryQuoteId { get; set; } // Identity column
        public long EnquiryId { get; set; }
        public string TemplateBody { get; set; }
        public decimal AdultNett { get; set; }
        public decimal ChildNett { get; set; }
        public decimal InfantNett { get; set; }
        public decimal PPPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal AdultSell { get; set; }
        public decimal ChildSell { get; set; }
        public decimal InfantSell { get; set; }
        public decimal TotalNett { get; set; }
        public DateTime? EmailSendDate { get; set; }
        public DateTime? EmailReadDate { get; set; }
        public bool IsAuto { get; set; }
        public bool IsDraft { get; set; }
        public byte NumberofAdult { get; set; }
        public byte NumberofChild { get; set; }
        public byte NumberofInfant { get; set; }
        public int? ModifiedById { get; set; }
        public DateTime? AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public short? QuoteExpiryTime { get; set; }
        public int? QuoteSendBy { get; set; }
        public int? PerformedByEmployeeId { get; set; }
        public string QuoteTitle { get; set; }
        public bool? IsVisible { get; set; }

        public virtual Enquiry Enquiry { get; set; }
        public virtual ICollection<QuoteFlight> QuoteFlight { get; set; }
        public virtual ICollection<QuoteProperty> QuoteProperties { get; set; }
        public virtual ICollection<QuoteCruise> QuoteCruises { get; set; }
        public virtual ICollection<QuoteVehicleHire> QuoteVehicleHires { get; set; }
    }
}
