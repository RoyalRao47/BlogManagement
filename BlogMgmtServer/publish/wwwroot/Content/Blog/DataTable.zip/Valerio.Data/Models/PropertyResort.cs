﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class PropertyResort
    {
        public short PropertyResortId { get; set; }
        public string PropertyResortName { get; set; }
        public short? PropertyRegionId { get; set; }
        //public int? ResortCodeId { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }

        // Navigation properties
        public virtual PropertyRegion PropertyRegion { get; set; }
       // public FlightAirport FlightAirport { get; set; }

    }
}
