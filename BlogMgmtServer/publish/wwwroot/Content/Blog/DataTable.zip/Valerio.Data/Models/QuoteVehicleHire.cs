﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class QuoteVehicleHire
    {
        public long QuoteVehicleHireId { get; set; }
        public long EnquiryQuoteId { get; set; }
        public short VehicleTypeId { get; set; }
        public short? VehicleDetailId { get; set; }
        public byte? VehicleHireTypeId { get; set; }
        public byte NoOfDrivers { get; set; }
        public DateTime? PickUpDate { get; set; }
        public byte Duration { get; set; }
        public byte Quantity { get; set; }
        public decimal VehicleNett { get; set; }
        public string Notes { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public string InternalNotes { get; set; }

        // Navigation properties
        public virtual EnquiryQuote EnquiryQuote { get; set; }
        public virtual VehicleType? VehicleType { get; set; }
        public virtual VehicleDetail? VehicleDetail { get; set; }
    }
}
