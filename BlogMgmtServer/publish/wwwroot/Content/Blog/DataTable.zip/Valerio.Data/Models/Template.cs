﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class Template
    {
        [Key]
        public byte TemplateId { get; set; }

        [Required]
        [MaxLength(100)]
        public string TemplateName { get; set; } = null!;

        [Required]
        public string OpeningText { get; set; } = null!;

      
        [Required]
        [MaxLength(100)]
        public string SubjectLine { get; set; } = null!;

        [Required]
        public DateTime AddDate { get; set; }

        [Required]
        public DateTime ModifyDate { get; set; }

        [Required]
        [MaxLength(15)]
        public string IPAddress { get; set; } = null!;

        [Required]
        public bool IsActive { get; set; }
    }
}
