﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class QuoteCruise
    {
        public long QuoteCruiseId { get; set; }
        public long EnquiryQuoteId { get; set; }
        public byte CruiseLineId { get; set; }
        public short ShipId { get; set; }
        public string SalesPoint { get; set; }
        public byte? NoOfCabin { get; set; }
        public byte CabinTypeId { get; set; }
        public byte Nights { get; set; }
        public decimal AdultNett { get; set; }
        public decimal ChildNett { get; set; }
        public decimal InfantNett { get; set; }
        public string Notes { get; set; }
        public DateTime? CheckInDate { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public string InternalNotes { get; set; }

        // Navigation properties
        public virtual EnquiryQuote EnquiryQuote { get; set; }
        public virtual Ship Ship { get; set; }
        public virtual CabinType CabinType { get; set; }
        public virtual CruiseLine CruiseLine { get; set; }
    }
}
