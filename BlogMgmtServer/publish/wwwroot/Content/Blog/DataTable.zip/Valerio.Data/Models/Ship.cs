﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class Ship
    {
        public short ShipId { get; set; }
        public string ShipName { get; set; }
        public string Description { get; set; }
        public short? CruiseSupplierId { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }
    }
}
