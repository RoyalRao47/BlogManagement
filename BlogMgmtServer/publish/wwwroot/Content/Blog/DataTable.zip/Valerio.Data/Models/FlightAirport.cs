﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class FlightAirport
    {
        public short FlightAirportId { get; set; }
        public string FlightAirportName { get; set; }
        public string AirportCode { get; set; }
        public bool IsDeparture { get; set; }
        public bool IsArrival { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }
    }
}
