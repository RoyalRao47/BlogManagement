﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Valerio.Data.Models;


namespace Valerio.Data.Models;

public partial class ValerioQuoteManagerContext : DbContext
{

    public ValerioQuoteManagerContext()
    {

    }

    public ValerioQuoteManagerContext(DbContextOptions<ValerioQuoteManagerContext> options)
        : base(options)
    {
    }
    public virtual DbSet<AdminUser> AdminUsers { get; set; }
    public virtual DbSet<Enquiry> Enquiries { get; set; }
    public virtual DbSet<GeneralSiteSetting> GeneralSiteSettings { get; set; }
    public virtual DbSet<MenuItem> MenuItems { get; set; }

    public virtual DbSet<RolePage> RolePages { get; set; }

    public virtual DbSet<RolePagePermission> RolePagePermissions { get; set; }

    public virtual DbSet<UserPermission> UserPermissions { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    public DbSet<Airline> Airlines { get; set; }
    public DbSet<FlightCabin> FlightCabins { get; set; }
    public DbSet<AirClass> AirClasses { get; set; }
    public DbSet<Destination> Destinations { get; set; }
    public DbSet<PropertyRegion> PropertyRegions { get; set; }
    public DbSet<RoomType> RoomTypes { get; set; }
    public DbSet<PropertyAccomType> PropertyAccomTypes { get; set; }
    public DbSet<PropertyResort> PropertyResorts { get; set; }
    public DbSet<Property> Properties { get; set; }
    public DbSet<FlightAirport> FlightAirports { get; set; }
    public DbSet<Ship> Ships { get; set; }
    public DbSet<CabinType> CabinTypes { get; set; }
    public DbSet<BoardBasis> BoardBasises { get; set; }
    public DbSet<CruiseLine> CruiseLines { get; set; }
    public DbSet<EnquiryQuote> EnquiryQuote { get; set; }
    public DbSet<QuoteFlight> QuoteFlights { get; set; }
    public DbSet<QuoteProperty> QuoteProperty { get; set; }
    public DbSet<QuoteFlightAdditionalLeg> QuoteFlightAdditionalLeg { get; set; }
    public DbSet<Template> Template { get; set; }
    public DbSet<QuoteCruise> QuoteCruise { get; set; }
    public DbSet<VehicleType> VehicleType { get; set; }
    public DbSet<VehicleDetail> VehicleDetail { get; set; }
    public DbSet<QuoteVehicleHire> QuoteVehicleHire { get; set; }
    public DbSet<EnquiryNote> EnquiryNote { get; set; }
    public DbSet<LogTable> LogTable { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            //optionsBuilder.UseSqlServer("Server=db1015572372.hosting-data.io;Database=db1015572372;User=dbo1015572372;Password=hs#dBsLnf!p_'u-5:#;Trusted_Connection=False;TrustServerCertificate=true;");
            optionsBuilder.UseSqlServer("Server=192.168.1.13;Database=ValerioQuoteManager-New;User=ValerioQuoteManager-New;Password=2dLJoMzVMdZ5;Trusted_Connection=False;TrustServerCertificate=true;");
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        modelBuilder.Entity<AdminUser>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__AdminUse__3214EC07FC5BB7A9");

            entity.ToTable("AdminUser");

            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.CreationOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DateOfBirth).HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(200);
            entity.Property(e => e.EncryptedPassword).HasMaxLength(200);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.ForgotPasswordLink).HasMaxLength(256);
            entity.Property(e => e.ForgotPasswordLinkExpired).HasColumnType("datetime");
            entity.Property(e => e.ImageName).HasMaxLength(1000);
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.MobilePhone).HasMaxLength(50);
            entity.Property(e => e.ModifiedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.SaltKey).HasMaxLength(200);

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.InverseCreatedByNavigation)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("FK__AdminUser__Creat__4222D4EF");

            entity.HasOne(d => d.ModifiedByNavigation).WithMany(p => p.InverseModifiedByNavigation)
                .HasForeignKey(d => d.ModifiedBy)
                .HasConstraintName("FK__AdminUser__Modif__4316F928");

            entity.HasOne(d => d.Role).WithMany(p => p.AdminUsers)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__AdminUser__RoleI__440B1D61");

            entity.HasMany(u => u.EnquiryNotes)
                  .WithOne(e => e.CreatedByUser)
                  .HasForeignKey(e => e.CreatedBy)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasMany(u => u.Enquiries)
                  .WithOne(e => e.AllocateEmployee)
                  .HasForeignKey(e => e.AllocateEmployeeId)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasMany(u => u.ModifiedEnquiries)
                  .WithOne(e => e.ModifiedByEmployee)
                  .HasForeignKey(e => e.ModifiedByEmployeeId)
                  .OnDelete(DeleteBehavior.Restrict);
        });


        modelBuilder.Entity<Enquiry>(entity =>
        {
            entity.ToTable("Enquiry");

            entity.Property(e => e.AdditionalInfo).HasMaxLength(500);
            entity.Property(e => e.CustomerFirstName).HasMaxLength(50);
            entity.Property(e => e.CustomerLastName).HasMaxLength(50);
            entity.Property(e => e.CustomerTitle).HasMaxLength(5);
            entity.Property(e => e.DepartureAirport).HasMaxLength(100);
            entity.Property(e => e.Destination).HasMaxLength(100);
            entity.Property(e => e.Duration).HasMaxLength(50);
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.HolidayType).HasMaxLength(50);
            entity.Property(e => e.HolidayValue).HasMaxLength(50);
            entity.Property(e => e.IntendtoBook).HasMaxLength(50);
            entity.Property(e => e.MultiCentre).HasMaxLength(5);
            entity.Property(e => e.PhoneNo).HasMaxLength(20);
            entity.Property(e => e.SecondDestination).HasMaxLength(100);
            entity.Property(e => e.SecondDuration).HasMaxLength(50);
            entity.Property(e => e.Transportation).HasMaxLength(100);

            entity.HasMany(e => e.EnquiryNotes)
           .WithOne(n => n.Enquiry)
           .HasForeignKey(n => n.EnquiryId);

        });

        modelBuilder.Entity<EnquiryNote>(entity =>
        {
            entity.ToTable("EnquiryNote");
            entity.Property(e => e.Note).HasMaxLength(2000);
        });

        modelBuilder.Entity<GeneralSiteSetting>(entity =>
        {
            entity.ToTable("GeneralSiteSetting");

            entity.Property(e => e.ApplyTaxPercent1).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ApplyTaxPercent2).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ApplyTaxPercentHeading1).HasMaxLength(50);
            entity.Property(e => e.ApplyTaxPercentHeading2).HasMaxLength(50);
            entity.Property(e => e.CreatedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DiscountFix).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.DiscountPercent).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.IsApplyDiscountFix).HasDefaultValue(false);
            entity.Property(e => e.IsApplyDiscountPercent).HasDefaultValue(false);
            entity.Property(e => e.KeyName).HasMaxLength(50);
            entity.Property(e => e.LogoImageExtension).HasMaxLength(20);
            entity.Property(e => e.LogoImageExtensionDark).HasMaxLength(20);
            entity.Property(e => e.LogoImageName).HasMaxLength(255);
            entity.Property(e => e.LogoImageNameDark).HasMaxLength(255);
            entity.Property(e => e.LogoOriginalImageName).HasMaxLength(255);
            entity.Property(e => e.LogoOriginalImageNameDark).HasMaxLength(255);
            entity.Property(e => e.ModifiedBy).HasDefaultValue(0L);
            entity.Property(e => e.ModifiedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.SiteName).HasMaxLength(80);
            entity.Property(e => e.SupportEmail).HasMaxLength(200);
            entity.Property(e => e.SupportMobile).HasMaxLength(20);
        });
        modelBuilder.Entity<MenuItem>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__MenuItem__3214EC07D255F672");

            entity.Property(e => e.CreatedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Icon).HasMaxLength(100);
            entity.Property(e => e.ModifiedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.SubMenuIcon).HasMaxLength(100);
            entity.Property(e => e.SubMenuName).HasMaxLength(50);
        });
        modelBuilder.Entity<RolePage>(entity =>
        {
            entity.ToTable("RolePage");

            entity.Property(e => e.CreatedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("Is_Active");
            entity.Property(e => e.PageName).HasMaxLength(100);
            entity.Property(e => e.PageUrl).HasMaxLength(250);
        });
        modelBuilder.Entity<RolePagePermission>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__RolePage__3214EC07279B7017");

            entity.ToTable("RolePagePermission");

            entity.HasOne(d => d.Page).WithMany(p => p.RolePagePermissions)
                .HasForeignKey(d => d.PageId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RolePagePermission_RolePage");

            entity.HasOne(d => d.Role).WithMany(p => p.RolePagePermissions)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__RolePageP__RoleI__3D89085B");
        });
        modelBuilder.Entity<UserPermission>(entity =>
        {
            entity.ToTable("UserPermission");

            entity.Property(e => e.CreatedOn).HasColumnType("datetime");

            entity.HasOne(d => d.Role).WithMany(p => p.UserPermissions)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull);
        });
        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__UserRole__3214EC07AC5AEF26");

            entity.Property(e => e.CreatedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsActive).HasColumnName("Is_Active");
            entity.Property(e => e.ModifiedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });
        modelBuilder.Entity<Airline>(entity =>
        {
            entity.ToTable("Airline");

            entity.HasKey(e => e.AirlineId)
                .HasName("PK_Airline");

            entity.Property(e => e.AirlineId).HasColumnName("AirlineId");

            entity.Property(e => e.AirlineName)
                .IsRequired()
                .HasMaxLength(150);

            entity.Property(e => e.AirlinLogo).HasMaxLength(100);

            entity.Property(e => e.AirlineLogo).HasMaxLength(100);

            entity.Property(e => e.Description).HasColumnType("ntext");

            entity.Property(e => e.AirlineIATACode).HasMaxLength(10);

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");

            entity.Property(e => e.OrderNumber).HasColumnType("int");

            entity.Property(e => e.IsPreferred).HasColumnType("bit");
        });
        modelBuilder.Entity<FlightCabin>(entity =>
        {
            entity.ToTable("FlightCabin");

            entity.HasKey(e => e.FlightCabinTypeId)
                .HasName("PK_FlightCabinTypeId");

            entity.Property(e => e.FlightCabinTypeId).HasColumnName("FlightCabinTypeId");

            entity.Property(e => e.FlightCabinTypeName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");
        });
        modelBuilder.Entity<AirClass>(entity =>
        {
            entity.ToTable("AirClass");

            entity.HasKey(e => e.AirClassId)
                .HasName("PK_AirClass");

            entity.Property(e => e.AirClassId).HasColumnName("AirClassId");

            entity.Property(e => e.AirlineId).HasColumnName("AirlineId");

            entity.Property(e => e.AirClassName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.ShortDescription).HasColumnType("nvarchar(max)");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");

            entity.Property(e => e.CabineTypeId).HasColumnName("CabineTypeId");

            // Relationships
            entity.HasOne(d => d.Airline)
                .WithMany()
                .HasForeignKey(d => d.AirlineId)
                .HasConstraintName("FK_AirClass_Airline");

            entity.HasOne(d => d.FlightCabin)
                .WithMany()
                .HasForeignKey(d => d.CabineTypeId)
                .HasConstraintName("FK_AirClass_FlightCabin");
        });
        modelBuilder.Entity<Destination>(entity =>
        {
            entity.ToTable("Destination");

            entity.HasKey(e => e.DestinationId)
                .HasName("PK_Destination");

            entity.Property(e => e.DestinationId).HasColumnName("DestinationId");

            entity.Property(e => e.DestinationName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.ParentId).HasColumnName("ParentId");

            entity.Property(e => e.IsProperty).HasColumnType("bit");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");
        });
        modelBuilder.Entity<PropertyRegion>(entity =>
        {
            entity.ToTable("PropertyRegion");

            entity.HasKey(e => e.PropertyRegionId)
                .HasName("PK_PropertyRegion");

            entity.Property(e => e.PropertyRegionId).HasColumnName("PropertyRegionId");

            entity.Property(e => e.PropertyRegionName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.PropertyDestId).HasColumnName("PropertyDestId");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");

            // Define foreign key relationship
            entity.HasOne(d => d.Destination)
                .WithMany()
                .HasForeignKey(d => d.PropertyDestId)
                .HasConstraintName("FK_PropertyRegion_Destination");
        });
        modelBuilder.Entity<RoomType>(entity =>
        {
            entity.ToTable("RoomType");

            entity.HasKey(e => e.RoomTypeId)
                .HasName("PK_RoomType");

            entity.Property(e => e.RoomTypeId).HasColumnName("RoomTypeId");

            entity.Property(e => e.RoomTypeName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.PropertyAccomTypeId).HasColumnName("PropertyAccomTypeId");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");

            entity.Property(e => e.IsPreferred).HasColumnType("bit");

            entity.Property(e => e.DisplayOrder).HasColumnName("DisplayOrder");

            // Define foreign key relationship
            entity.HasOne(d => d.PropertyAccomType)
                .WithMany()
                .HasForeignKey(d => d.PropertyAccomTypeId)
                .HasConstraintName("FK_RoomType_PropertyAccomType");
        });
        modelBuilder.Entity<PropertyAccomType>(entity =>
        {
            entity.ToTable("PropertyAccomType");

            entity.HasKey(e => e.PropertyAccomTypeId)
                .HasName("PK_PropertyAccomType");

            entity.Property(e => e.PropertyAccomTypeId).HasColumnName("PropertyAccomTypeId");

            entity.Property(e => e.PropertyAccomTypeName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.Description).HasMaxLength(250);

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");

            entity.Property(e => e.DisplayOrder).HasColumnName("DisplayOrder");
        });
        modelBuilder.Entity<PropertyResort>(entity =>
        {
            entity.ToTable("PropertyResort");

            entity.HasKey(e => e.PropertyResortId)
                .HasName("PK_PropertyResort");

            entity.Property(e => e.PropertyResortId).HasColumnName("PropertyResortId");

            entity.Property(e => e.PropertyResortName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.PropertyRegionId).HasColumnName("PropertyRegionId");

            // entity.Property(e => e.ResortCodeId).HasColumnName("ResortCodeId");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");

            // Foreign keys
            entity.HasOne(d => d.PropertyRegion)
                .WithMany()
                .HasForeignKey(d => d.PropertyRegionId)
                .HasConstraintName("FK_PropertyResort_PropertyRegion");

            //entity.HasOne(d => d.FlightAirport)
            //    .WithMany()
            //    .HasForeignKey(d => d.ResortCodeId)
            //    .HasConstraintName("FK_PropertyResort_FlightAirport");
        });
        modelBuilder.Entity<Property>(entity =>
        {
            entity.ToTable("Property");

            entity.HasKey(e => e.PropertyId)
                .HasName("PK_Property");

            entity.Property(e => e.PropertyId).HasColumnName("PropertyId");

            entity.Property(e => e.PropertyName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.PropertyDestId).HasColumnName("PropertyDestId");

            entity.Property(e => e.PropertyRegionId).HasColumnName("PropertyRegionId");

            entity.Property(e => e.PropertyResortId).HasColumnName("PropertyResortId");

            entity.Property(e => e.Description).HasColumnType("nvarchar(max)");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");

            entity.Property(e => e.RoomTypeId).HasColumnName("RoomTypeId");

            entity.Property(e => e.AccomRatingId).HasColumnName("AccomRatingId");

            entity.Property(e => e.PropertyAccomTypeId).HasColumnName("PropertyAccomTypeId");

            entity.Property(e => e.IsShowDisneyTicketTransfer).HasColumnType("bit");

            entity.Property(e => e.IsBookingCaption).HasColumnType("bit");
            entity.Property(e => e.PropertyImage).HasColumnType("nvarchar(max)");

            // Foreign keys
            entity.HasOne(d => d.Destination)
                .WithMany()
                .HasForeignKey(d => d.PropertyDestId)
                .HasConstraintName("FK_Property_Destination")
                .OnDelete(DeleteBehavior.Restrict); // Adjust cascade behavior here

            entity.HasOne(d => d.PropertyRegion)
                .WithMany()
                .HasForeignKey(d => d.PropertyRegionId)
                .HasConstraintName("FK_Property_PropertyRegion")
                .OnDelete(DeleteBehavior.Restrict); // Adjust cascade behavior here

            entity.HasOne(d => d.PropertyResort)
                .WithMany()
                .HasForeignKey(d => d.PropertyResortId)
                .HasConstraintName("FK_Property_PropertyResort")
                .OnDelete(DeleteBehavior.Restrict); // Adjust cascade behavior here

            entity.HasOne(d => d.RoomType)
                .WithMany()
                .HasForeignKey(d => d.RoomTypeId)
                .HasConstraintName("FK_Property_RoomType")
                .OnDelete(DeleteBehavior.Restrict); // Adjust cascade behavior here

            entity.HasOne(d => d.PropertyAccomType)
                .WithMany()
                .HasForeignKey(d => d.PropertyAccomTypeId)
                .HasConstraintName("FK_Property_PropertyAccomType")
                .OnDelete(DeleteBehavior.Restrict); // Adjust cascade behavior here
        });
        modelBuilder.Entity<FlightAirport>(entity =>
        {
            entity.ToTable("FlightAirport");

            entity.HasKey(e => e.FlightAirportId)
                .HasName("PK_FlightAirport");

            entity.Property(e => e.FlightAirportId).HasColumnName("FlightAirportId");

            entity.Property(e => e.FlightAirportName)
                .IsRequired()
                .HasMaxLength(150);

            entity.Property(e => e.AirportCode)
                .IsRequired()
                .HasMaxLength(5);

            entity.Property(e => e.IsDeparture).HasColumnType("bit");

            entity.Property(e => e.IsArrival).HasColumnType("bit");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");
        });
        modelBuilder.Entity<Ship>(entity =>
        {
            entity.ToTable("Ship");

            entity.HasKey(e => e.ShipId)
                .HasName("PK_Ship");

            entity.Property(e => e.ShipId).HasColumnName("ShipId");

            entity.Property(e => e.ShipName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.Description).HasColumnType("ntext");

            entity.Property(e => e.CruiseSupplierId).HasColumnName("CruiseSupplierId");

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");
        });
        modelBuilder.Entity<CabinType>(entity =>
        {
            entity.ToTable("CabinType");

            entity.Property(e => e.CabinTypeId).ValueGeneratedOnAdd();
            entity.Property(e => e.CabinTypeName).HasMaxLength(100);
            entity.Property(e => e.Ipaddress)
                .HasMaxLength(45)
                .HasColumnName("IPAddress");
        });
        modelBuilder.Entity<BoardBasis>(entity =>
        {
            entity.ToTable("BoardBasis");

            entity.HasKey(e => e.BoardBasisId)
                .HasName("PK_BoardBasis");

            entity.Property(e => e.BoardBasisId).HasColumnName("BoardBasisId");

            entity.Property(e => e.BoardBasisName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");

            entity.Property(e => e.IPAddress).HasMaxLength(45);

            entity.Property(e => e.IsActive).HasColumnType("bit");
        });
        modelBuilder.Entity<CruiseLine>(entity =>
        {
            entity.ToTable("CruiseLine");

            entity.HasKey(e => e.CruiseLineId)
                .HasName("PK_CruiseLine");

            entity.Property(e => e.CruiseLineId).HasColumnName("CruiseLineId");

            entity.Property(e => e.CruiseLineName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(e => e.AddDate).HasColumnType("datetime2");

            entity.Property(e => e.IsActive).HasColumnType("bit");
        });
        modelBuilder.Entity<QuoteFlight>(entity =>
        {
            entity.HasKey(e => e.QuoteFlightId);
            entity.Property(e => e.QuoteFlightId).IsRequired().ValueGeneratedOnAdd();
            entity.Property(e => e.EnquiryQuoteId).IsRequired();
            entity.Property(e => e.IsFlightDirect).IsRequired();
            entity.Property(e => e.IsIncludeTaxes).IsRequired();
            entity.Property(e => e.AdultNett).IsRequired().HasColumnType("decimal(8,2)");
            entity.Property(e => e.ChildNett).IsRequired().HasColumnType("decimal(8,2)");
            entity.Property(e => e.InfantNett).IsRequired().HasColumnType("decimal(8,2)");
            entity.Property(e => e.Notes).IsRequired().HasMaxLength(2000);
            entity.Property(e => e.EmployeeId).IsRequired();
            entity.Property(e => e.AddDate).IsRequired();
            entity.Property(e => e.ModifyDate).IsRequired();
            entity.Property(e => e.IPAddress).IsRequired().HasMaxLength(45);
            entity.Property(e => e.Duration).IsRequired(false);
            entity.Property(e => e.ManualAirline).HasMaxLength(200);
            entity.Property(e => e.SalesPoint).IsRequired(false).HasColumnType("nvarchar(max)");

            entity.HasOne(e => e.EnquiryQuote)
                  .WithMany()
                  .HasForeignKey(e => e.EnquiryQuoteId)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.Airline)
                  .WithMany()
                  .HasForeignKey(e => e.AirlineId)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.AirClass)
                  .WithMany()
                  .HasForeignKey(e => e.AirClassId)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<QuoteProperty>(entity =>
        {
            entity.HasKey(e => e.QuotePropertyId);
            entity.Property(e => e.DestinationId).IsRequired();
            entity.Property(e => e.RegionId).IsRequired(false);
            entity.Property(e => e.ResortId).IsRequired(false);
            entity.Property(e => e.PropertyId).IsRequired(false);
            entity.Property(e => e.ManualPropertyName).HasMaxLength(200).IsRequired(false);
            entity.Property(e => e.PropertyAccomTypeId).IsRequired();
            entity.Property(e => e.Rooms).IsRequired();
            entity.Property(e => e.RoomTypeId).IsRequired(false);
            entity.Property(e => e.ManualRoomType).HasMaxLength(200).IsRequired(false);
            entity.Property(e => e.Beds).IsRequired();
            entity.Property(e => e.Nights).IsRequired();
            entity.Property(e => e.BoardBasisId).IsRequired(false);
            entity.Property(e => e.AccomNett)
                .IsRequired()
                .HasColumnType("decimal(18,2)");
            entity.Property(e => e.Notes)
                .IsRequired()
                .HasMaxLength(2000);
            entity.Property(e => e.CheckInDate)
                .IsRequired(false)
                .HasColumnType("datetime2");
            entity.Property(e => e.SalesPoint)
                .IsRequired()
                .HasColumnType("nvarchar(max)");
            entity.Property(e => e.IsPoolHeat).IsRequired();
            entity.Property(e => e.ItineraryId).IsRequired(false);
            entity.Property(e => e.ItineraryName).HasMaxLength(200).IsRequired();
            entity.Property(e => e.SortLegIndex).IsRequired();
            entity.Property(e => e.AddDate)
                .IsRequired()
                .HasColumnType("datetime2");
            entity.Property(e => e.ModifyDate)
                .IsRequired()
                .HasColumnType("datetime2");
            entity.Property(e => e.IPAddress)
                .IsRequired()
                .HasMaxLength(45);
            entity.Property(e => e.ExternalURL).HasMaxLength(2000).IsRequired(false);
            entity.Property(e => e.InternalNotes).HasMaxLength(2000).IsRequired(false);
            entity.Property(e => e.CERate)
                .IsRequired(false)
                .HasColumnType("decimal(8,2)");
            entity.Property(e => e.AccomNettPound)
                .IsRequired(false)
                .HasColumnType("decimal(8,2)");
            entity.Property(e => e.ManualRegionandResort).HasMaxLength(500).IsRequired(false);
            entity.HasOne(e => e.Destination)
                  .WithMany()
                  .HasForeignKey(e => e.DestinationId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.PropertyRegion)
                  .WithMany()
                  .HasForeignKey(e => e.RegionId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.PropertyResort)
                  .WithMany()
                  .HasForeignKey(e => e.ResortId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.Property)
                  .WithMany()
                  .HasForeignKey(e => e.PropertyId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.PropertyAccomType)
                  .WithMany()
                  .HasForeignKey(e => e.PropertyAccomTypeId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.RoomType)
                  .WithMany()
                  .HasForeignKey(e => e.RoomTypeId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.BoardBasis)
                  .WithMany()
                  .HasForeignKey(e => e.BoardBasisId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(d => d.EnquiryQuote)
                 .WithMany()
                 .HasForeignKey(d => d.EnquiryQuoteId)
                 .HasConstraintName("FK_QuoteProperty_EnquiryQuote");
        });
        modelBuilder.Entity<EnquiryQuote>(entity =>
        {
            entity.ToTable("EnquiryQuote");

            entity.HasKey(e => e.EnquiryQuoteId)
                  .HasName("PK_EnquiryQuote")
                  .IsClustered(false);

            entity.Property(e => e.EnquiryQuoteId)
                  .ValueGeneratedOnAdd(); // Identity column configuration

            entity.Property(e => e.AdultNett).HasColumnType("decimal(18,2)");
            entity.Property(e => e.ChildNett).HasColumnType("decimal(18,2)");
            entity.Property(e => e.InfantNett).HasColumnType("decimal(18,2)");
            entity.Property(e => e.PPPrice).HasColumnType("decimal(18,2)");
            entity.Property(e => e.TotalPrice).HasColumnType("decimal(18,2)");
            entity.Property(e => e.AdultSell).HasColumnType("decimal(18,2)");
            entity.Property(e => e.ChildSell).HasColumnType("decimal(18,2)");
            entity.Property(e => e.InfantSell).HasColumnType("decimal(18,2)");
            entity.Property(e => e.TotalNett).HasColumnType("decimal(18,2)");

            entity.Property(e => e.EmailSendDate).HasColumnType("datetime2");
            entity.Property(e => e.EmailReadDate).HasColumnType("datetime2");
            entity.Property(e => e.IsAuto).HasColumnType("bit");
            entity.Property(e => e.IsDraft).HasColumnType("bit");
            entity.Property(e => e.NumberofAdult).HasColumnType("tinyint");
            entity.Property(e => e.NumberofChild).HasColumnType("tinyint");
            entity.Property(e => e.NumberofInfant).HasColumnType("tinyint");
            entity.Property(e => e.ModifiedById).HasColumnType("int");
            entity.Property(e => e.AddDate).HasColumnType("datetime2");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime2");
            entity.Property(e => e.IPAddress).HasMaxLength(45).IsUnicode(false);
            entity.Property(e => e.QuoteExpiryTime).HasColumnType("smallint");
            entity.Property(e => e.QuoteSendBy).HasColumnType("int");
            entity.Property(e => e.PerformedByEmployeeId).HasColumnType("int");
            entity.Property(e => e.QuoteTitle).HasMaxLength(250).IsUnicode(true);
            entity.Property(e => e.IsVisible).HasColumnType("bit");
            entity.Property(e => e.TemplateBody).HasColumnType("nvarchar(max)");

            entity.HasOne(d => d.Enquiry)
                  .WithMany()
                  .HasForeignKey(d => d.EnquiryId)
                  .HasConstraintName("FK_EnquiryQuote_Enquiry");

            entity.HasMany(e => e.QuoteFlight)
           .WithOne(q => q.EnquiryQuote)
           .HasForeignKey(q => q.EnquiryQuoteId);

            entity.HasMany(e => e.QuoteProperties)
            .WithOne(q => q.EnquiryQuote)
            .HasForeignKey(q => q.EnquiryQuoteId);

            entity.HasMany(e => e.QuoteCruises)
           .WithOne(q => q.EnquiryQuote)
           .HasForeignKey(q => q.EnquiryQuoteId);

            entity.HasMany(e => e.QuoteVehicleHires)
            .WithOne(q => q.EnquiryQuote)
            .HasForeignKey(q => q.EnquiryQuoteId);

        });

        modelBuilder.Entity<QuoteFlightAdditionalLeg>(entity =>
        {
            entity.ToTable("QuoteFlightAdditionalLeg");

            entity.HasKey(e => e.QuoteFlightAdditionalId)
                  .IsClustered(false)
                  .HasName("PK_QuoteFlightAdditionalLeg");

            entity.Property(e => e.QuoteFlightAdditionalId)
                  .IsRequired()
                  .UseIdentityColumn();

            entity.Property(e => e.QuoteFlightId)
                  .IsRequired();

            entity.Property(e => e.AirClassId);

            entity.Property(e => e.DepartureDate);

            entity.Property(e => e.Duration)
                  .IsRequired();

            entity.Property(e => e.DepartAirportId);

            entity.Property(e => e.ArrivalAirportId);

            entity.Property(e => e.ArrivalDateTime);

            entity.Property(e => e.SortLegIndex);

            entity.Property(e => e.IsInbound);

            entity.Property(e => e.ManualClass)
                  .HasMaxLength(200);

            entity.Property(e => e.FlightNumber)
                  .HasMaxLength(100);

            entity.Property(e => e.SeatNumber)
                  .HasMaxLength(1600);

            entity.Property(e => e.NoOfStops);

            // Relationships
            entity.HasOne(d => d.QuoteFlight)
                  .WithMany(p => p.QuoteFlightAdditionalLegs)
                  .HasForeignKey(d => d.QuoteFlightId)
                  .HasConstraintName("FK_QuoteFlightAdditionalLeg_QuoteFlights");

            entity.HasOne(d => d.AirClass)
                  .WithMany()
                  .HasForeignKey(d => d.AirClassId)
                  .HasConstraintName("FK_QuoteFlightAdditionalLeg_AirClass");

            entity.HasOne(d => d.DepartAirport)
                  .WithMany()
                  .HasForeignKey(d => d.DepartAirportId)
                  .HasConstraintName("FK_QuoteFlightAdditionalLeg_Departure_FlightAirport");

            entity.HasOne(d => d.ArrivalAirport)
                  .WithMany()
                  .HasForeignKey(d => d.ArrivalAirportId)
                  .HasConstraintName("FK_QuoteFlightAdditionalLeg_Arrival_FlightAirport");
        });
        modelBuilder.Entity<Template>(entity =>
        {
            entity.ToTable("Template");

            entity.Property(e => e.TemplateId)
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.TemplateName)
                  .IsRequired()
                  .HasMaxLength(100);

            entity.Property(e => e.OpeningText)
                  .IsRequired();
            entity.Property(e => e.SubjectLine)
                  .IsRequired()
                  .HasMaxLength(100);

            entity.Property(e => e.AddDate)
                  .IsRequired();

            entity.Property(e => e.ModifyDate)
                  .IsRequired();

            entity.Property(e => e.IPAddress)
                  .IsRequired()
                  .HasMaxLength(45)
                  .HasColumnName("IPAddress");

            entity.Property(e => e.IsActive)
                  .IsRequired();
        });

        modelBuilder.Entity<QuoteCruise>(entity =>
        {
            entity.ToTable("QuoteCruise");

            entity.HasKey(e => e.QuoteCruiseId)
            .HasName("PK_QuoteCruise");

            entity.Property(e => e.QuoteCruiseId)
            .ValueGeneratedOnAdd();

            entity.Property(e => e.EnquiryQuoteId)
            .IsRequired();

            entity.Property(e => e.ShipId)
            .IsRequired();

            entity.Property(e => e.CruiseLineId)
            .IsRequired();

            entity.Property(e => e.SalesPoint)
            .HasMaxLength(int.MaxValue);

            entity.Property(e => e.NoOfCabin)
            .HasColumnType("tinyint");

            entity.Property(e => e.CabinTypeId)
            .IsRequired()
            .HasColumnType("tinyint");

            entity.Property(e => e.Nights)
            .IsRequired()
            .HasColumnType("tinyint");

            entity.Property(e => e.AdultNett)
            .IsRequired()
            .HasColumnType("decimal(8, 2)");

            entity.Property(e => e.ChildNett)
            .IsRequired()
            .HasColumnType("decimal(8, 2)");

            entity.Property(e => e.InfantNett)
            .IsRequired()
            .HasColumnType("decimal(8, 2)");

            entity.Property(e => e.Notes)
            .HasMaxLength(2000);

            entity.Property(e => e.CheckInDate)
            .HasColumnType("datetime2");

            entity.Property(e => e.AddDate)
            .IsRequired()
            .HasColumnType("datetime2");

            entity.Property(e => e.ModifyDate)
            .IsRequired()
            .HasColumnType("datetime2");

            entity.Property(e => e.IPAddress)
            .IsRequired()
            .HasMaxLength(45);

            entity.Property(e => e.InternalNotes)
            .HasMaxLength(2000);

            // Relationships

            //entity.HasOne(d => d.EnquiryQuote)
            //.WithMany()
            //.HasForeignKey(d => d.EnquiryQuoteId)
            //.OnDelete(DeleteBehavior.Restrict)
            //.HasConstraintName("FK_QuoteCruise_EnquiryQuote");

            //entity.HasOne(d => d.Ship)
            //.WithMany()
            //.HasForeignKey(d => d.ShipId)
            //.OnDelete(DeleteBehavior.Restrict)
            //.HasConstraintName("FK_QuoteCruise_Ship");

            //entity.HasOne(d => d.CabinType)
            //.WithMany()
            //.HasForeignKey(d => d.CabinTypeId)
            //.OnDelete(DeleteBehavior.Restrict)
            //.HasConstraintName("FK_QuoteCruise_CabinType");
        });

        modelBuilder.Entity<VehicleType>(entity =>
        {
            entity.HasKey(e => e.VehicleTypeId)
            .HasName("PK_VehicleTypeId");

            entity.Property(e => e.VehicleTypeId)
            .ValueGeneratedOnAdd();

            entity.Property(e => e.VehicleTypeName)
                  .IsRequired()
                  .HasMaxLength(100);

            entity.Property(e => e.AddDate)
                  .IsRequired();

            entity.Property(e => e.ModifyDate);

            entity.Property(e => e.IPAddress)
                  .IsRequired()
                  .HasMaxLength(45);

            entity.Property(e => e.IsActive)
                  .IsRequired();
        });
        modelBuilder.Entity<VehicleDetail>(entity =>
        {
            entity.HasKey(e => e.VehicleDetailId)
            .HasName("PK_VehicleDetail");

            entity.Property(e => e.VehicleDetailId)
            .ValueGeneratedOnAdd();

            entity.Property(e => e.VehicleDetailName)
                  .IsRequired()
                  .HasMaxLength(100);

            entity.Property(e => e.Description);

            entity.Property(e => e.TotalPassengers);

            entity.Property(e => e.VehicleTypeId)
                  .IsRequired();

            entity.Property(e => e.AddDate)
                  .IsRequired();

            entity.Property(e => e.ModifyDate);

            entity.Property(e => e.IPAddress)
                  .IsRequired()
                  .HasMaxLength(45);

            entity.Property(e => e.IsActive)
                  .IsRequired();

            entity.HasOne(e => e.VehicleType)
                  .WithMany()
                  .HasForeignKey(e => e.VehicleTypeId)
                  .HasConstraintName("FK_VehicleType_VehicleDetail");
        });

        modelBuilder.Entity<QuoteVehicleHire>(entity =>
        {
            entity.HasKey(e => e.QuoteVehicleHireId)
            .HasName("PK_QuoteVehicleHire");

            entity.Property(e => e.QuoteVehicleHireId)
            .ValueGeneratedOnAdd();

            entity.Property(e => e.VehicleNett)
                  .HasColumnType("decimal(8, 2)");

            entity.Property(e => e.Notes)
                      .HasMaxLength(2000);

            entity.Property(e => e.IPAddress)
                  .IsRequired()
                  .HasMaxLength(45);

            entity.Property(e => e.InternalNotes)
                  .HasMaxLength(2000);

            entity.HasOne(e => e.VehicleType)
                  .WithMany()
                  .HasForeignKey(e => e.VehicleTypeId)
                  .HasConstraintName("FK_QuoteVehicleHire_VehicleType");

            entity.HasOne(e => e.VehicleDetail)
                  .WithMany()
                  .HasForeignKey(e => e.VehicleDetailId)
                  .HasConstraintName("FK_QuoteVehicleHire_VehicleDetail");
        });

        modelBuilder.Entity<LogTable>(entity =>
        {
            entity.ToTable("LogTable");

            entity.HasKey(e => e.Id);

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd();

            entity.Property(e => e.LogDate)
                .IsRequired();

            entity.Property(e => e.LogLevel)
                .IsRequired()
                .HasMaxLength(50);

            entity.Property(e => e.Message)
                .IsRequired();

            entity.Property(e => e.Logger)
                .IsRequired()
                .HasMaxLength(250);

            entity.Property(e => e.Exception);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
