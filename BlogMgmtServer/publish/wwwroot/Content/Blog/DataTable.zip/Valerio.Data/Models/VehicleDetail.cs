﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class VehicleDetail
    {
        public short VehicleDetailId { get; set; }
        public string VehicleDetailName { get; set; }
        public string Description { get; set; }
        public int? TotalPassengers { get; set; }
        public short VehicleTypeId { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }
        public virtual VehicleType VehicleType { get; set; }

    }
}
