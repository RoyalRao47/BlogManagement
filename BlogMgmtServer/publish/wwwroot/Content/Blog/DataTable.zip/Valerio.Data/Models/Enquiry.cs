﻿using System;
using System.Collections.Generic;

namespace Valerio.Data.Models;

public class Enquiry
{
    public long EnquiryId { get; set; }

    public string? CustomerTitle { get; set; }

    public string CustomerFirstName { get; set; } = null!;

    public string CustomerLastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string PhoneNo { get; set; } = null!;

    public string HolidayType { get; set; } = null!;

    public string DepartureAirport { get; set; } = null!;

    public string Destination { get; set; } = null!;

    public string Transportation { get; set; } = null!;

    public DateTime DepartureDate { get; set; }

    public string Duration { get; set; } = null!;

    public short Adults { get; set; }

    public short Children { get; set; }

    public short Infants { get; set; }

    public string? MultiCentre { get; set; }

    public string? SecondDestination { get; set; }

    public string? SecondDuration { get; set; }

    public string? HolidayValue { get; set; }

    public string? IntendtoBook { get; set; }

    public string? AdditionalInfo { get; set; }

    public DateTime? EnquiryDate { get; set; }

    public int Status { get; set; }

    public long? AllocateEmployeeId { get; set; }
    public DateTime? AllocatedDate { get; set; }
    public long? ModifiedByEmployeeId { get; set; }
    public DateTime? ModifiedDate { get; set; }
    public DateTime CreatedDate { get; set; }

    public virtual AdminUser? AllocateEmployee {  get; set; }
    public virtual AdminUser? ModifiedByEmployee {  get; set; }

    public virtual ICollection<EnquiryNote> EnquiryNotes { get; set; }
}
