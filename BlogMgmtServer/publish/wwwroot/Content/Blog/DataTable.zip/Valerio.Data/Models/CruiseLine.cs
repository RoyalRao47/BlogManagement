﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class CruiseLine
    {
        public byte CruiseLineId { get; set; }
        public string CruiseLineName { get; set; }
        public DateTime AddDate { get; set; }
        public bool IsActive { get; set; }
    }
}
