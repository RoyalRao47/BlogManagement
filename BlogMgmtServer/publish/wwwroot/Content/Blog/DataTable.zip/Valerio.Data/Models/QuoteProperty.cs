﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class QuoteProperty
    {
        public long QuotePropertyId { get; set; }
        public long EnquiryQuoteId { get; set; }
        public short DestinationId { get; set; }

        public short? RegionId { get; set; }

        public short? ResortId { get; set; }

        public short? PropertyId { get; set; }

        [MaxLength(200)]
        public string ManualPropertyName { get; set; }

        public byte PropertyAccomTypeId { get; set; }

        public byte Rooms { get; set; }

        public short? RoomTypeId { get; set; }

        [MaxLength(200)]
        public string ManualRoomType { get; set; }

        public byte Beds { get; set; }
        public byte Nights { get; set; }

        public byte? BoardBasisId { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal AccomNett { get; set; }

        [MaxLength(2000)]
        public string Notes { get; set; }

        public DateTime? CheckInDate { get; set; }

        [Column(TypeName = "nvarchar(max)")]
        public string SalesPoint { get; set; }

        public byte IsPoolHeat { get; set; }

        public byte? ItineraryId { get; set; }

        [MaxLength(200)]
        public string ItineraryName { get; set; }

        public byte SortLegIndex { get; set; }

        public DateTime AddDate { get; set; }

        public DateTime ModifyDate { get; set; }

        [MaxLength(15)]
        public string IPAddress { get; set; }

        [MaxLength(2000)]
        public string ExternalURL { get; set; }

        [MaxLength(2000)]
        public string InternalNotes { get; set; }

        [Column(TypeName = "decimal(8,2)")]
        public decimal? CERate { get; set; }

        [Column(TypeName = "decimal(8,2)")]
        public decimal? AccomNettPound { get; set; }

        [MaxLength(500)]
        public string ManualRegionandResort { get; set; }

        public virtual Destination Destination { get; set; }
        public virtual PropertyRegion PropertyRegion { get; set; }
        public virtual PropertyResort PropertyResort { get; set; }
        public virtual Property Property { get; set; }
        public virtual PropertyAccomType PropertyAccomType { get; set; }

        public virtual RoomType RoomType { get; set; }
        public virtual BoardBasis BoardBasis { get; set; }
        public virtual EnquiryQuote EnquiryQuote { get; set; }


    }
}
