﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Data.Models
{
    public class RoomType
    {
        public short RoomTypeId { get; set; }
        public string RoomTypeName { get; set; }
        public byte? PropertyAccomTypeId { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public string IPAddress { get; set; }
        public bool IsActive { get; set; }
        public bool? IsPreferred { get; set; }
        public int? DisplayOrder { get; set; }

        // Navigation property
        public virtual PropertyAccomType PropertyAccomType { get; set; }
    }
}
