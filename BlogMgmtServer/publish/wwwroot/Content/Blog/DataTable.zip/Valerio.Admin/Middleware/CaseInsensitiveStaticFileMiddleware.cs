﻿using Microsoft.Extensions.FileProviders;

namespace Valerio.Admin.Middleware
{
    public class CaseInsensitiveStaticFileMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IFileProvider _fileProvider;

        public CaseInsensitiveStaticFileMiddleware(RequestDelegate next, IFileProvider fileProvider)
        {
            _next = next;
            _fileProvider = fileProvider;
        }

        public async Task Invoke(HttpContext context)
        {
            var requestPath = context.Request.Path.Value;

            if (string.IsNullOrEmpty(requestPath))
            {
                await _next(context);
                return;
            }

            var normalizedPath = NormalizePath(requestPath);

            if (normalizedPath != null)
            {
                context.Request.Path = new PathString(normalizedPath);
            }

            await _next(context);
        }

        private string? NormalizePath(string requestPath)
        {
            var segments = requestPath.Split('/');
            var currentDirectory = _fileProvider.GetDirectoryContents("/");

            foreach (var segment in segments)
            {
                if (string.IsNullOrEmpty(segment))
                    continue;

                var normalizedSegment = FindSegmentIgnoreCase(currentDirectory, segment);
                if (normalizedSegment == null)
                    return null;

                currentDirectory = _fileProvider.GetDirectoryContents(normalizedSegment);
            }

            return string.Join('/', segments);
        }

        private string? FindSegmentIgnoreCase(IDirectoryContents directoryContents, string segment)
        {
            foreach (var fileInfo in directoryContents)
            {
                if (fileInfo.Name.Equals(segment, StringComparison.OrdinalIgnoreCase))
                    return fileInfo.Name;
            }

            return null;
        }
    }
}
