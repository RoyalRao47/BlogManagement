﻿using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using Valerio.Service;

namespace Valerio.Admin.Middleware
{
    public class CheckUserStatusMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly SignInManager<IdentityUser> _signInManager;

        public CheckUserStatusMiddleware(RequestDelegate next, IServiceScopeFactory serviceScopeFactory, SignInManager<IdentityUser> signInManager)
        {
            _next = next;
            _serviceScopeFactory = serviceScopeFactory;
            _signInManager = signInManager;
        }

        public async Task Invoke(HttpContext context)
        {
            if (context.User.Identity.IsAuthenticated)
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var adminUserService = scope.ServiceProvider.GetRequiredService<IAdminUserService>();
                    var userId = context.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var user = adminUserService.GetAdminUserById(long.Parse(userId));
                    if (user != null && user.IsActive.HasValue && !user.IsActive.Value)
                    {
                        // Sign out the user
                        await _signInManager.SignOutAsync();

                        // Redirect to login page or show an error
                        context.Response.Redirect("/Account/Login");
                        return;
                    }
                }
            }

            await _next(context);
        }
    }

}
