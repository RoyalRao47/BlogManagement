using Valerio.Core.Code.LIBS;
using Valerio.Data.Models;
using Valerio.Repo;
using Valerio.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;
using FluentValidation.AspNetCore;
using Valerio.Admin.ViewModels.Flights;
using Valerio.Service.Quote;
using Valerio.Admin.Filters;
using NLog.Web;
using NLog;
using Valerio.Admin.Middleware;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.FileProviders;
using FluentAssertions.Common;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Localization;
using System.Globalization;
using Microsoft.AspNetCore.Builder;
using Valerio.Service.Customer;


var logger = NLog.LogManager.Setup().LoadConfigurationFromAppSettings().GetCurrentClassLogger();
logger.Debug("init main");

try
{

    var builder = WebApplication.CreateBuilder(args);

    builder.Logging.ClearProviders();
    builder.Host.UseNLog();

    builder.Configuration.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
    builder.Services.AddRazorPages();
    builder.Services.AddOptions();
    builder.Services.AddHttpContextAccessor();
    builder.Services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
    builder.Services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
    builder.Services.AddDbContext<ValerioQuoteManagerContext>(options => options.UseSqlServer(
        builder.Configuration.GetConnectionString("DBConnection")).UseLazyLoadingProxies());
    
    SiteKeys.Configure(builder.Configuration.GetSection("AppSetting"));

    //builder.Services.AddAuthentication("BasicAuthentication")
    //      .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", null);

    //builder.Services.AddAuthorization(options =>
    //{
    //    options.AddPolicy("BasicAuthentication", new AuthorizationPolicyBuilder("BasicAuthentication").RequireAuthenticatedUser().Build());
    //});

    builder.Services.Configure<IISServerOptions>(options =>
    {
        options.AllowSynchronousIO = true;
    });

    builder.Services.Configure<CookiePolicyOptions>(options =>
    {
        options.CheckConsentNeeded = context => true;
        options.MinimumSameSitePolicy = SameSiteMode.None;
    });
    builder.Services.AddDistributedMemoryCache();
    builder.Services.AddAuthentication("AdminScheme").AddCookie("AdminScheme", opt =>
    {
        opt.ExpireTimeSpan= TimeSpan.FromDays(1);   
        opt.LoginPath = "/account/index";
    });
    builder.Services.AddSession(options =>
    {
        options.IdleTimeout = TimeSpan.FromDays(1);
        options.IOTimeout = TimeSpan.FromDays(1);
        options.Cookie.IsEssential = true;
        options.Cookie.HttpOnly = true;
    });

    builder.Services.Configure<KestrelServerOptions>(options =>
    {
        options.AllowSynchronousIO = true;
    });

    builder.Services.Configure<IISServerOptions>(options =>
    {
        options.AllowSynchronousIO = true;
    });
    builder.Services.Configure<CookieTempDataProviderOptions>(options =>
    {
        options.Cookie.Expiration = TimeSpan.FromDays(1);
        options.Cookie.IsEssential = true;
        options.Cookie.HttpOnly = true;

        options.Cookie.Name = "AdminAuthCookie";
        options.Cookie.Path = "/admin"; // Path for admin-specific cookies
    });
    builder.Services.AddMvc()
            .AddSessionStateTempDataProvider();

    builder.Services.AddHttpClient();

    builder.Services.AddSession();
  
    builder.Services.Configure<IISServerOptions>(options =>
    {
        options.MaxRequestBodySize = long.MaxValue;
    });

    builder.WebHost.ConfigureKestrel(options =>
    {
        options.Limits.MaxRequestBodySize = long.MaxValue; // Set your desired max size here
    });

    builder.Services.AddControllersWithViews()
        .AddFluentValidation(fv => fv.RegisterValidatorsFromAssemblyContaining<AirlineViewModelValidator>());

    builder.Services.AddRazorPages().AddRazorRuntimeCompilation();//if deploy issue then remove
    builder.Services.Configure<RequestLocalizationOptions>(options =>
    {
        var supportedCultures = new[] { new CultureInfo("en-GB") };
        options.DefaultRequestCulture = new RequestCulture("en-US");
        options.SupportedCultures = supportedCultures;
        options.SupportedUICultures = supportedCultures;
    });

    InitServices(builder.Services);

    var app = builder.Build();
    var supportedCultures = new[] { new CultureInfo("en-GB") };
    var localizationOptions = new RequestLocalizationOptions
    {
        DefaultRequestCulture = new RequestCulture("en-GB"),
        SupportedCultures = supportedCultures,
        SupportedUICultures = supportedCultures
    };

    app.UseRequestLocalization(localizationOptions);
    app.UseForwardedHeaders(new ForwardedHeadersOptions
    {
        ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
    });

    IHostEnvironment env = app.Environment;

    // Configure the HTTP request pipeline.
    if (!app.Environment.IsDevelopment())
    {
        app.UseExceptionHandler("/Home/Error");
        // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
        app.UseHsts();
    }

    app.UseExceptionHandler(
        options =>
        {
            options.Run(
            async context =>
            {
                context.Response.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
                context.Response.ContentType = "text/html";
                var ex = context.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerFeature>();
                if (ex != null)
                {
                    var err = $"<h1>Error: {ex.Error.Message}</h1>{ex.Error.StackTrace}";
                    await context.Response.WriteAsync(err).ConfigureAwait(false);
                }
            });
        }
    );

    app.UseHttpsRedirection();
    app.UseStaticFiles();
    app.UseStatusCodePages();
    app.UseAuthentication();
    app.UseSession();
    app.UseRouting();
    app.UseAuthorization();
   // app.UseRequestLocalization<localizationOptions>();
    app.MapControllerRoute(
        name: "default",
        pattern: "{controller=Account}/{action=Index}/{id?}");

    app.UseCookiePolicy();

    ContextProvider.Configure(app.Services.GetRequiredService<IHttpContextAccessor>());
    app.UseMiddleware<ExceptionHandlingMiddleware>();
    app.Run();
}
catch (Exception exception)
{
    // NLog: catch setup errors
    logger.Error(exception, "Stopped program because of exception");
    throw;
}
finally
{
    NLog.LogManager.Shutdown();
}

void InitServices(IServiceCollection services)
{
    services.AddScoped<EnquiryAssignmentFilter>();
    services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
    services.AddScoped<IAdminUserService, AdminUserService>();
    services.AddScoped<IUserRoleService, UserRoleService>();
    services.AddScoped<IPermissionService, PermissionService>();
    services.AddScoped<ISettingService, SettingService>();
    services.AddScoped<IEnquiryService, EnquiryService>();
    services.AddScoped<IAirlineService, AirlineService>();
    services.AddScoped<IAirClassService, AirClassService>();
    services.AddScoped<IFlightAirportService, FlightAirportService>();
    services.AddScoped<ICabinTypeService, CabinTypeService>();
    services.AddScoped<IEnquiryQuoteService, EnquiryQuoteService>();
    services.AddScoped<IEnquiryDestinationService, EnquiryDestinationService>();
    services.AddScoped<IQuoteCommonService, QuoteCommonService>();
    services.AddScoped<IPropertyService, PropertyService>();
    services.AddScoped<IBoardBasisService, BoardBasisService>();
    services.AddScoped<IPropertyAccommodationTypeService, PropertyAccommodationTypeService>();
    services.AddScoped<IPropertyRegionService, PropertyRegionService>();
    services.AddScoped<IPropertyResortService, PropertyResortService>();
    services.AddScoped<IAccommodationRoomTypeService, AccommodationRoomTypeService>();
    services.AddScoped<IDestinationService, DestinationService>();
    services.AddScoped<IShipService, ShipService>();
    services.AddScoped<ICruiseLineService, CruiseLineService>();
    services.AddScoped<IEmailSenderService, EmailSenderService>();
    services.AddScoped<IEmailSendService, EmailSendService>();
    services.AddScoped<IVehicleTypeService, VehicleTypeService>();
    services.AddScoped<IVehicleDetailService, VehicleDetailService>();
    services.AddScoped<IRoomTypeService, RoomTypeService>();
    services.AddScoped<IFlightCabinService, FlightCabinService>();
    services.AddScoped<ICustomerService, CustomerService>();
    //services.AddScoped<BasicAuthFilter>();
}

