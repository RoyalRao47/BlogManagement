﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace Valerio.Admin.Filters
{
    public class BasicAuthFilter : IAuthorizationFilter
    {
        private readonly string _username;
        private readonly string _password;

        public BasicAuthFilter(IConfiguration configuration)
        {
            _username = configuration["BasicAuth:Username"];
            _password = configuration["BasicAuth:Password"];
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            if (!context.HttpContext.Request.Headers.ContainsKey("Authorization"))
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            var authHeader = context.HttpContext.Request.Headers["Authorization"].ToString();
            if (authHeader.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
            {
                var token = authHeader.Substring("Basic ".Length).Trim();
                var credentialString = Encoding.UTF8.GetString(Convert.FromBase64String(token));
                var credentials = credentialString.Split(':');
                if (credentials.Length == 2 && credentials[0] == _username && credentials[1] == _password)
                {
                    return;
                }
            }

            context.Result = new UnauthorizedResult();
        }
    }
}
