﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Valerio.Service;

namespace Valerio.Admin.Filters
{
    public class EnquiryAssignmentFilter : IActionFilter
    {
        private readonly IEnquiryService _enquiryService;
        private readonly ILogger<EnquiryAssignmentFilter> _logger;

        public EnquiryAssignmentFilter(IEnquiryService enquiryService, ILogger<EnquiryAssignmentFilter> logger)
        {
            _enquiryService = enquiryService;
            _logger = logger;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.ActionArguments.ContainsKey("id") || context.ActionArguments.ContainsKey("enquiryid"))
            {
                var enquiryId = context.ActionArguments.ContainsKey("enquiryid") ?
                                (long)context.ActionArguments["enquiryid"] :
                                (int)context.ActionArguments["id"];
                var enquiry = _enquiryService.GetEnquiryById(enquiryId);

                var userId = "";
                var Role = "";
                var data = context.HttpContext.User?.Claims.ToList();
                for (int i = 0; i < data.Count; i++)
                {
                    if (i == 3)
                    {
                        Role = data[i].Value;
                    }
                    if (i == 4)
                    {
                        userId = data[i].Value;
                    }
                }
                if (Role.ToLower() != "superadmin")
                {
                    if (userId == null || userId != enquiry.AllocateEmployeeId.ToString())
                    {
                        _logger.LogInformation($"User {userId} is not authorized to view this enquiry ");
                        context.Result = new RedirectToActionResult("AccessDenied", "Enquiry", null);
                    }
                }

            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            // No action required after the method execution
        }
    }
}
