﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Core
{
    public struct UploadSectionGroup
    {
        public const string PackageImage = "PackageImage";
        public const string PackageVideo = "PackageVideo";
        public const string HotelImages = "HotelImages";
    }
}
