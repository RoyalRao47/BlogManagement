﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Core.Code.LIBS
{
    public class DateRange
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
    public class DateRangeCalculator
    {
        public static DateRange GetThisWeek()
        {
            DateTime today = DateTime.Today;
            int daysUntilMonday = ((int)today.DayOfWeek + 6) % 7; // Calculate days until Monday
            DateTime monday = today.AddDays(-daysUntilMonday);

            DateTime startDate = monday; // Current Monday
            DateTime endDate = today; // Current day

            return new DateRange { StartDate = startDate, EndDate = endDate };
        }
        public static DateRange GetLastWeek()
        {
            DateTime today = DateTime.Today;
            int daysUntilPreviousSunday = (int)today.DayOfWeek;
            DateTime lastSunday = today.AddDays(-daysUntilPreviousSunday);

            DateTime startDate = lastSunday.AddDays(-6); // Last Sunday - 6 days
            DateTime endDate = lastSunday; // Last Sunday

            return new DateRange { StartDate = startDate, EndDate = endDate };
        }

        public static DateRange GetThisMonth()
        {
            DateTime today = DateTime.Today;
            DateTime startDate = new DateTime(today.Year, today.Month, 1);
            DateTime endDate = startDate.AddMonths(1).AddDays(-1);

            return new DateRange { StartDate = startDate, EndDate = endDate };
        }

        public static DateRange GetLastMonth()
        {
            DateTime today = DateTime.Today;
            DateTime firstDayOfThisMonth = new DateTime(today.Year, today.Month, 1);
            DateTime firstDayOfLastMonth = firstDayOfThisMonth.AddMonths(-1);
            DateTime lastDayOfLastMonth = firstDayOfThisMonth.AddDays(-1);

            return new DateRange { StartDate = firstDayOfLastMonth, EndDate = lastDayOfLastMonth };
        }
    }
}
