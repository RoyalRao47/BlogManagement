﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Core.Code.Enums
{
    public enum DateTimeFormatEnum
    {
        [Description("dd/MM/yyyy")]
        ShortDate = 1,
        [Description("dd/MM/yyyy hh:mm tt")]
        LongDate = 2,
        [Description("dd/MM/yyyy HH:mm")]
        LongDate24 = 3,
        [Description("dd MMM yyyy")]
        DateForDisplay = 4,
        [Description("MMM dd yyyy hh:mm tt")]
        DateWithMonthName = 5,
        [Description("dMMyy")]
        ShortDate1 = 6,
        [Description("MM/dd/yyyy hh:mm tt")]
        LongDate12 = 7,
        [Description("ddd MMM dd, yyyy")]
        PSLongDate24 = 8,
        [Description("hh:mm tt")]
        TimeFormat = 9,
        [Description("HH:mm")]
        ShortTime24 = 10,
        [Description("hh:mm tt")]
        ShortTime12 = 11,
    }
}
