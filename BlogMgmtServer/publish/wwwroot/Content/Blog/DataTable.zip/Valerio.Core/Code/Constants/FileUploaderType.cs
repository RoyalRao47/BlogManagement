﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Core
{
    public struct FileUploaderType
    {
        public const string Single = "signle";
        public const string Multiple = "multiple";
    }
}
