﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Core.Code
{
    public enum EnumDisplayAttribute
    {
        Name,
        GroupName,
        Prompt,
        Description,
        Title
    }
    public enum FlightType : byte
    {
        [Description("Direct Flights")]
        DirectFlights = 1,
        [Description("Indirect Flights")]
        IndirectFlights = 2,
        [Description("Do Not Specify")]
        DoNotSpecify = 3,
    }
    public static class EnumExtensions
    {
        public static string GetDescription(this Enum value)
        {
            var field = value.GetType().GetField(value.ToString());
            var attribute = field.GetCustomAttribute<DescriptionAttribute>();
            return attribute == null ? value.ToString() : attribute.Description;
        }
    }

    public enum EnquairyStatus
    {
        [Description("New")]
        New = 1,
        [Description("Allocated")]
        Allocated = 2,
        [Description("In-Process")]
        Inprocess = 3,
        [Description("Hold")]
        Hold = 4,
        [Description("Quoted")]
        Quoted = 5,
        [Description("Booked")]
        Booked = 6,
        [Description("Cancel")]
        Cancel = 7,
    }

}
