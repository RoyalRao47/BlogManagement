﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valerio.Core.Code
{
    public enum PoolHeat
    {
        Yes = 1,
        No = 2,
        [Description("N/A")]
        NA = 0
    }
}
